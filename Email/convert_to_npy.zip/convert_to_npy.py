

from osgeo import gdal
import numpy as np

# Path to the GeoTIFF image
image_path = 'I:/sar_image/datasets_sentinal1/email/s1a-iw1-slc-vv-20230406t231942-20230406t232007-047982-05c44e-004.tiff.tif'

# Output path for the .npy file
output_numpy_path = 'I:/sar_image/datasets_sentinal1/email/output_data1.npy'

# Open the image using GDAL
dataset = gdal.Open(image_path)

if dataset is None:
    print("Failed to open the image.")
else:
    print("Converting GeoTIFF to NumPy array...")

    # List to store all band data
    band_data_list = []
    
    # Loop through all bands and read them as arrays
    for i in range(1, dataset.RasterCount + 1):
        band = dataset.GetRasterBand(i)
        band_data = band.ReadAsArray()
        band_data_list.append(band_data)
        print(f"Band {i} shape: {band_data.shape}")

    # Stack all bands into a single NumPy array (e.g., [bands, rows, cols])
    combined_array = np.stack(band_data_list, axis=0)
    print(f"Combined array shape: {combined_array.shape}")

    # Save the NumPy array to a .npy file
    np.save(output_numpy_path, combined_array)
    print(f"GeoTIFF converted and saved as {output_numpy_path}")

    # Optional: Check the saved .npy file
    loaded_array = np.load(output_numpy_path)
    print(f"Loaded array shape (from .npy): {loaded_array.shape}")

