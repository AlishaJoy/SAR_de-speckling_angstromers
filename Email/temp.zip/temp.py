from osgeo import gdal
import numpy as np
import os

# Path to the GeoTIFF image
image_path = 'I:/sar_image/datasets_sentinal1/email/s1a-iw1-slc-vv-20230406t231942-20230406t232007-047982-05c44e-004.tiff.tif'


'''
# Open the image using GDAL
dataset = gdal.Open(image_path)

# Check if the dataset was successfully loaded
if dataset is None:
    print("Failed to open the image.")
else:
    # Get the number of bands
    num_bands = dataset.RasterCount
    print(f"Number of bands: {num_bands}")
   
    # Optionally, print details for each band
    for i in range(1, num_bands + 1):
        band = dataset.GetRasterBand(i)
        print(f"Band {i}: Data type: {gdal.GetDataTypeName(band.DataType)}, NoData Value: {band.GetNoDataValue()}")
    
'''


# Open the image using GDAL
dataset = gdal.Open(image_path)

# Check if the dataset was successfully loaded
if dataset is None:
    print("Failed to open the image.")
else:
    # General dataset properties
    print("General Dataset Information:")
    print(f"  Driver: {dataset.GetDriver().ShortName}/{dataset.GetDriver().LongName}")
    print(f"  Raster size: {dataset.RasterXSize} x {dataset.RasterYSize}")
    print(f"  Number of bands: {dataset.RasterCount}")
    print(f"  Projection: {dataset.GetProjection()}")
    print(f"  Geotransform: {dataset.GetGeoTransform()}")
    print()

    # Loop through bands and extract additional information
    for i in range(1, dataset.RasterCount + 1):
        band = dataset.GetRasterBand(i)
        print(f"Band {i} Details:")
        print(f"  Data type: {gdal.GetDataTypeName(band.DataType)}")
        print(f"  NoData Value: {band.GetNoDataValue()}")
        print(f"  Block size: {band.GetBlockSize()}")
        print(f"  Minimum Value: {band.GetMinimum()}")
        print(f"  Maximum Value: {band.GetMaximum()}")

        # Calculate statistics if not available
        if band.GetMinimum() is None or band.GetMaximum() is None:
            band.ComputeStatistics(False)
            print(f"  Updated Statistics: Min={band.GetMinimum()}, Max={band.GetMaximum()}")
        
        # Get band scale and offset
        print(f"  Scale: {band.GetScale()}")
        print(f"  Offset: {band.GetOffset()}")

        # Read band as array (for further processing)
        band_array = band.ReadAsArray()
        print(f"  Array shape: {band_array.shape}")
        print()

    # Get corner coordinates
    print("Corner Coordinates:")
    transform = dataset.GetGeoTransform()
    def get_coordinates(x, y):
        geo_x = transform[0] + x * transform[1] + y * transform[2]
        geo_y = transform[3] + x * transform[4] + y * transform[5]
        return geo_x, geo_y

    corners = {
        "Top Left": get_coordinates(0, 0),
        "Top Right": get_coordinates(dataset.RasterXSize, 0),
        "Bottom Left": get_coordinates(0, dataset.RasterYSize),
        "Bottom Right": get_coordinates(dataset.RasterXSize, dataset.RasterYSize),
    }

    for corner, coords in corners.items():
        print(f"  {corner}: {coords}")





